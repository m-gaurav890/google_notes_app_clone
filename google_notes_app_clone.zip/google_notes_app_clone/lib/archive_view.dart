import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:google_notes_app_clone/side_menu_bar.dart';

import 'NoteView.dart';
import 'colors.dart';
import 'create_note_view.dart';

class ArchiveView extends StatefulWidget {
  const ArchiveView({super.key});

  @override
  State<ArchiveView> createState() => _ArchiveViewState();
}

class _ArchiveViewState extends State<ArchiveView> {
  final GlobalKey<ScaffoldState> _drawerKey = GlobalKey();
  String note =
      "This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is note This is no";
  String note1 = "This is note This is note This is note This is note ";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton:  FloatingActionButton(
        onPressed: (){
          Navigator.push(context, MaterialPageRoute(builder: (context)=>const CreateNoteView()));
        },
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        backgroundColor: bgColor,
        elevation: 1,
        foregroundColor: white,
        child: const Icon(Icons.add,size: 40,),
      ),
      endDrawerEnableOpenDragGesture: true,
      key: _drawerKey,
      drawer: const SideMenu(),
      backgroundColor: bgColor,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  //Search container
                  margin:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                          color: black.withOpacity(0.2),
                          spreadRadius: 1,
                          blurRadius: 3)
                    ],
                    borderRadius: BorderRadius.circular(10),
                    color: cardColor,
                  ),
                  width: MediaQuery.of(context).size.width,
                  height: 50,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          TextButton(
                            onPressed: () {
                              _drawerKey.currentState!.openDrawer();
                            },
                            child: Icon(
                              Icons.menu,
                              color: white,
                            ),
                          ),
                          Container(
                            height: 50,
                            width: 200,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text(
                                  "Search Your Notes",
                                  style: TextStyle(
                                      fontSize: 18,
                                      color: white.withOpacity(0.5)),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),

                      //second Row
                      Container(
                        padding: const EdgeInsets.only(right: 5),
                        child: Row(
                          children: [
                            TextButton(
                              onPressed: () {},
                              child: Icon(
                                Icons.grid_view,
                                color: white,
                              ),
                            ),
                            const SizedBox(
                              width: 16,
                            ),
                            const CircleAvatar(
                              radius: 19,
                              backgroundColor: Colors.greenAccent,
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                noteSectionAll(),
                noteListSection(),








                //colour wala notes

                // Container(
                //   margin:
                //   const EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                //   child: MasonryGridView.builder(
                //     physics: const NeverScrollableScrollPhysics(),
                //     gridDelegate:
                //     const SliverSimpleGridDelegateWithFixedCrossAxisCount(
                //         crossAxisCount: 2),
                //     itemCount: 10,
                //     mainAxisSpacing: 12,
                //     crossAxisSpacing: 12,
                //     shrinkWrap: true,
                //     itemBuilder: (context, index) => Container(
                //       padding: const EdgeInsets.symmetric(
                //           vertical: 10, horizontal: 10),
                //       decoration: BoxDecoration(
                //         color: index.isEven?Colors.green.shade900:Colors.blue.shade700,
                //           border: Border.all(
                //             color: index.isEven?Colors.green.withOpacity(0.4):Colors.blue.shade900.withOpacity(0.4),
                //           ),
                //           borderRadius: BorderRadius.circular(20)),
                //       child: Column(
                //         crossAxisAlignment: CrossAxisAlignment.start,
                //         children: [
                //           Text(
                //             "Heading",
                //             style: TextStyle(
                //                 color: white,
                //                 fontSize: 22,
                //                 fontWeight: FontWeight.bold),
                //           ),
                //           const SizedBox(
                //             height: 10,
                //           ),
                //           Text(
                //             index.isEven ? note.length>250?"${note.substring(0,250)}.....":note : note1,
                //             style: TextStyle(color: white, fontSize: 18),
                //           ),
                //         ],
                //       ),
                //     ),
                //   ),
                // ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget noteSectionAll(){
    return  Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin:
          const EdgeInsets.symmetric(horizontal: 25, vertical: 10),
          child: Column(
            children: [
              Text(
                "All",
                style: TextStyle(
                    color: white.withOpacity(0.5),
                    fontSize: 13,
                    fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
        Container(
          margin:
          const EdgeInsets.symmetric(horizontal: 10, vertical: 15),
          child: MasonryGridView.builder(
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate:
            const SliverSimpleGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2),
            itemCount: 11,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            shrinkWrap: true,
            itemBuilder: (context, index) => InkWell(
              onTap: (){
                //code here
              },
              child: Container(
                padding: const EdgeInsets.symmetric(
                    vertical: 10, horizontal: 10),
                decoration: BoxDecoration(
                    border: Border.all(
                      color: white.withOpacity(0.4),
                    ),
                    borderRadius: BorderRadius.circular(20)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Heading",
                      style: TextStyle(
                          color: white,
                          fontSize: 22,
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Text(
                      index.isEven ? note.length>250?"${note.substring(0,250)}.....":note : note1,
                      style: TextStyle(color: white, fontSize: 18),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
  Widget noteListSection(){
    return  Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin:
          const EdgeInsets.symmetric(horizontal: 25, vertical: 10),
          child: Column(
            children: [
              Text(
                "List View",
                style: TextStyle(
                    color: white.withOpacity(0.5),
                    fontSize: 13,
                    fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
        Container(
          margin:
          const EdgeInsets.symmetric(horizontal: 10, vertical: 15),
          child: ListView.builder(
            physics: const NeverScrollableScrollPhysics(),
            itemCount: 11,
            shrinkWrap: true,
            itemBuilder: (context, index) => Container(
              margin: EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.symmetric(
                  vertical: 10, horizontal: 10),
              decoration: BoxDecoration(
                  border: Border.all(
                    color: white.withOpacity(0.4),
                  ),
                  borderRadius: BorderRadius.circular(20)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Heading",
                    style: TextStyle(
                        color: white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Text(
                    index.isEven ? note.length>250?"${note.substring(0,250)}.....":note : note1,
                    style: TextStyle(color: white, fontSize: 18),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );


  }
}